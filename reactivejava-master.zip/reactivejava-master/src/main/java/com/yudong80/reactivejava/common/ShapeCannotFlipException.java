package com.yudong80.reactivejava.common;

public class ShapeCannotFlipException extends Exception {
	//do nothing
}
